package store.logic;

import java.util.List;

import domain.Record;
import store.RecordStore;

public class RecordStoreLogic implements RecordStore{

	@Override
	public String create(Record record) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Record search(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Record record) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(String userId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Record> winSearch() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Record> loseSearch() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Record> totalSearch() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Record> rateSearch() {
		// TODO Auto-generated method stub
		return null;
	}

}
