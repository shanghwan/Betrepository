$(document).ready(function(){

	$('#banner ul').cycle({
		fx: 'fade' // choose your transition type, ex: fade, scrollUp, shuffle, etc...
	});

});